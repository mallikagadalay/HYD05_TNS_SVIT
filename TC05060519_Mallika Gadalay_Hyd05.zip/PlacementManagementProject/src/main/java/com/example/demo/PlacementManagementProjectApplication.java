package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementManagementProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementManagementProjectApplication.class, args);
	}

}
